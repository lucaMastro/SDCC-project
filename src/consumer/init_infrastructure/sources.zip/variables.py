MESSAGE_BUCKET_NAME = "message-bucket-sdcc-20-21"
db_identifier = 'sdcc-rds'
database='users_db'
user='admin'
password='sdcc-db-admin'
